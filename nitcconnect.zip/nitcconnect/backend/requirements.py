Flask==2.3.2
Flask-Cors==3.0.10
PyJWT==2.8.0
bcrypt==4.0.1
requests==2.31.0
beautifulsoup4==4.12.2
